
export const changeStep = step => ({
    type: 'CHANGE_STEP',
    step
  })
  
  